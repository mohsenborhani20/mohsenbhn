function Gain = cardioid2D(phi, phi_0, phi_HB)

  m = abs( (log10(2))./log10(.5+.5*cos(phi_HB) ) );
  Gain = (.5*(1+cos(phi-phi_0))).^(m);