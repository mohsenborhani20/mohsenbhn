%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Matlab codes for Example 22.1 
% Quaternion matrix calculation using gyroscopes
% Author: Seong-hoon Peter Won
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Angular velocity inputs
Wx = 1;
Wy = 1;
Wz = 1;
dt= 0.01; %sampling time
 
% initial orientation is the same as the local fixed frame
a = 1;
b = 0;
c = 0;
d = 0;
 
for i=1:100  % run for 1 second (dt=0.01 second)
 
     a_dot = -0.5 * (b * Wx + c * Wy + d * Wz);
     b_dot = 0.5  * (a * Wx - d * Wy + c * Wz);
     c_dot = 0.5  * (d * Wx + a * Wy - b * Wz);
     d_dot = -0.5 * (c * Wx - b * Wy - a * Wz);
 
     a1 = a + a_dot*dt;
     b1 = b + b_dot*dt;
     c1 = c + c_dot*dt;
     d1 = d + d_dot*dt;
 
     a=a1/(a1^2+b1^2+c1^2+d1^2);
     b=b1/(a1^2+b1^2+c1^2+d1^2);
     c=c1/(a1^2+b1^2+c1^2+d1^2);
     d=d1/(a1^2+b1^2+c1^2+d1^2);


% find rotation matrix component
     c11 = a^2 + b^2 - c^2 - d^2;
     c12 = 2 * (b * c - a * d);
     c13 = 2 * (b * d + a * c);
 
     c21 = 2 * (b * c + a * d);
     c22 = a^2 - b^2 + c^2 - d^2;
     c23 = 2 * (c * d - a * b);
 
     c31 = 2 * (b * d - a * c);
     c32 = 2 * (c * d + a * b);
     c33 = a^2 - b^2 - c^2 + d^2;
     % 3 by 3 rotation matrix
C=[c11 c12 c13; c21 c22 c23; c31 c32 c33]; 
 
% Find x, y, z orientation component
     Lx=C*[1 0 0]';
     Ly=C*[0 1 0]';
     Lz=C*[0 0 1]';
 
% draw the local frame orientation 
     hold off
     plot3 ([1 0], [0 0], [0 0],'LineWidth',2 ,'Color', 'r');    % x-axis
     title(['Time: ',num2str(i/100), ' Sec'], 'Fontsize', 20);
     hold on  
     plot3 ([0 0], [1 0], [0 0],'LineWidth',2 ,'Color', 'b');    % y-axis
     plot3 ([0 0], [0 0], [1 0],'LineWidth',2 ,'Color', 'k');    % z-axis
% draw the body frame orientation 
     plot3 ([Lx(1) 0], [Lx(2) 0], [Lx(3) 0], 'r');     % x-axis
     plot3 ([Ly(1) 0], [Ly(2) 0], [Ly(3) 0],  'b');    % y-axis
     plot3 ([Lz(1) 0], [Lz(2) 0], [Lz(3) 0],  'k');    % z-axis
     axis([-1,1,-1,1,-1,1]);
     drawnow
end 

