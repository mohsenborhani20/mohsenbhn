% Definition of the Room and BS: 
 Room = [5, 4];  BS = [2.5, 2, 1.5];

 % discretization of the room.
 Dx = [0: .10: Room(1)];  Dy = [0: .10: Room(2)];
 [DX, DY] = meshgrid(Dx, Dy);
 
 %%% angular definition
 theta = [0:pi/90: pi];  phi = [-pi:pi/90: pi]; 

 % Typical Pattern for a hemi-dodecahedron. 
 theta_HB = deg2rad(50); % realistic HP Angle for a Patch
 theta_dihe = pi-acos(-1/sqrt(5));  %half of the diehedral angle 
 phi_dihe = 2*pi/5;  % the increasing angle around phi

 G1 = 10*log10(cardioid3D(theta, phi, 0, 0, theta_HB)); 
 G2 = 10*log10(cardioid3D(theta, phi, theta_dihe, 0, theta_HB)); 
 G3 = 10*log10(cardioid3D(theta, phi, theta_dihe, phi_dihe, theta_HB)); 
 G4 = 10*log10(cardioid3D(theta, phi, theta_dihe, 2*phi_dihe, theta_HB)); 
 G5 = 10*log10(cardioid3D(theta, phi, theta_dihe, 3*phi_dihe, theta_HB)); 
 G6 = 10*log10(cardioid3D(theta, phi, theta_dihe, 4*phi_dihe, theta_HB)); 

 %%% Distribution of Power over the Room floor, with the effect 
 % of Free Loss (np), unknown for the user. 
 M1 = Projector(theta, phi, G1, DX, DY, BS, np);
 M2 = Projector(theta, phi, G2, DX, DY, BS, np);
 M3 = Projector(theta, phi, G3, DX, DY, BS, np);
 M4 = Projector(theta, phi, G4, DX, DY, BS, np);
 M5 = Projector(theta, phi, G5, DX, DY, BS, np);
 M6 = Projector(theta, phi, G6, DX, DY, BS, np);
 Map = cat(3, M1, M2, M3, M4, M5, M6);

 %%% Projection of the Gains:
 GM1 = Projector(theta, phi, G1, DX, DY, BS, 0);
 GM2 = Projector(theta, phi, G2, DX, DY, BS, 0);
 GM3 = Projector(theta, phi, G3, DX, DY, BS, 0);
 GM4 = Projector(theta, phi, G4, DX, DY, BS, 0);
 GM5 = Projector(theta, phi, G5, DX, DY, BS, 0);
 GM6 = Projector(theta, phi, G6, DX, DY, BS, 0);
 GMap = cat(3, GM1, GM2, GM3, GM4, GM5, GM6);

 %% the real DOA is chosen  
 doa_x_index = 10; doa_y_index = 10;
 doa_x = Dx(doa_x_index);   doa_y = Dy(doa_y_index);  

 % Received Power 
 Received_Power = squeeze(Map(doa_y_index,  doa_x_index, :))';

 % RSSI, i.e. floor of the Received Power + gaussian noise.
 RSSI = floor( repmat(Received_Power, [Repetition,1]) +...
                         (10^(-.1*SNR))*randn(Repetition,6));