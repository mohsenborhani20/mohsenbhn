function C = cardioid_2D(theta, phi, theta_0, phi_0, theta_HB)

  %  The cardioid is parameterized by the pointing (theta_0, phi_0) 
  %  and by the Half Beam angle (theta_HB)

  % First, the meshgrid of the angular variables 
  [THETA, PHI]=meshgrid(theta, phi);

  % Then the angle between the vector defined by the pointing beam
  % theta_0 & phi_0 and the generic point theta & phi 
  % inverting the LAW OF COSINES:
  theta_rel = acos( cos(THETA).*cos(theta_0) +...
              sin(THETA).*sin(theta_0).*cos(PHI-phi_0) );

  % The sharpness of the cardioid depends on the exponent.
  % This exponent depends on the half power angle theta_HB:
  m = .5*abs( (log10(2))/log10( cos(theta_HB/2) ) );

  % Finally, the cardioid surface has formally the same expression 
  % of the common cardiod:
  C = ( .5*(1 + cos(theta_rel)) ).^m;