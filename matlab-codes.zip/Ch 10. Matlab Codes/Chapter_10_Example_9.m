function patpro = Projector(theta, phi, pattern, DX, DY, BS_pos, np)

  % The room side are parametrized by DX & DY, while the BaseStation 
  % is located in BS_pos, a vector of length 3 representing x,y & z.

  % RLOS, radial distance of a generic point from the 
  % projection of BS over the floor
  RLOS = sqrt((DX-BS_pos(1)).^2 + (DY-BS_pos(2)).^2);

  % DLOS, effective distance from the BS
  DLOS = sqrt(RLOS.^2 + BS_pos(3).^2);

  % Angular variable defined by the BS reference
  theta_room = (atan2(RLOS, BS_pos(3)));
  phi_room = (atan2((DX-BS_pos(1)), (DY-BS_pos(2))));
  
  % map creation: 
  patpro = griddata(theta, phi, pattern, theta_room, phi_room);
  
  % effective map with the loss contribute. 
  lambda = 0.2998/2.45;
  patpro = patpro - np*10*log10(4*pi*DLOS/lambda);