function x = gn_nls(X,r,iter)
% Nonlinear Least Squares
% Local search scheme: Gauss-Netwon algorithm
% --------------------------------
% x = 2D position estimate
% X = matrix for receiver positions
% r = TOA measurement vector
% iter = number of iterations
% sigma2 = noise variance vector
% 
L = size(X,2); % number of receivers
x = lls(X,r);
for i = 1:iter
    G = jacob(X, x);
    f_TOA = sqrt(sum((ones(L,1)*x'-X').^2,2));
    x = x+inv(G'*G)*G'*(r-f_TOA);
end