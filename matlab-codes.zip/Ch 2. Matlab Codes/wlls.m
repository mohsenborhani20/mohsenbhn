function x = wlls(X,r,sigma2)
% WLLS algorithm
% --------------------------------
% x = wlls(X,r,sigma2);
% x = 2D position estimate
% X = matrix for receiver positions
% r = TOA measurement vector
% sigma2 = noise variance vector
% 

L = size(X,2); % number of receivers
A = [-2*X' ones(L,1)];
b = r.^2-sum(X'.^2,2);
W = 1/4*diag(1./(sigma2.*r.^2));
p = pinv(A'*W*A)*A'*W*b;
x= [p(1) ; p(2)];


