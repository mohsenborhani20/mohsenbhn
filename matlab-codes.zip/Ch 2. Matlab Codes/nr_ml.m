function x = nr_ml(X,r,iter,sigma2)
% Maximum Likelihood
% Local search scheme: Newton-Raphson algorithm
% --------------------------------
% x = nr_ml(X,r,iter,sigma2);
% x = 2D position estimate
% X = matrix for receiver positions
% r = TOA measurement vector
% iter = number of iterations
% sigma2 = noise variance vector
%

x=wlls(X,r,sigma2);
for i=1:iter
    H=hessian_ml(X,x,r,sigma2);
    g=grad_ml(X,x,r,sigma2);
    x=x-inv(H)*g;
end



