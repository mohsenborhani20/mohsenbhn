   phi = [-pi:pi/90:pi];  gain = zeros(length(phi), 8);

   for i = 1:8
   gain(:,i) = cardioid2D(phi, pi/4.*i, deg2rad(60));
   end