% RMSE of the position estimate as a function of the cell radius

clc
clear all
c = 3 * 10^8;
beta_bar = 2 * pi * (1/sqrt(3)) * 5 * 10^6;
B = 7;
M = 2; % base stations receiving NLOS
a_range = [4.6 4.0 3.6];
b_range = [0.0075 0.0065 0.0050];
c_range = [12.6 17.1 20.0];
scenario_range = [1:length(a_range)];
h_b = 45; % (80+10)/2c
f = 1.9 * 10^9;
d_0 = 100;
kappa = c^2 / (16 * pi^2 * f^2 * d_0^2);
l_true = 100 * ones(M,1);
n_scenario = 0;
N_R = 10000;
SNR_dB = 120;
SNR = 10^(SNR_dB/10);
%r_range = 10.^[2:.1:3.5];
r_range = [200:200:3000];
n_r = 0;
for r = r_range;
    n_r = n_r + 1;
    p = (1/2) * r * cos(pi/6)* [cos(pi/6);sin(pi/6)];
    p_true = p;
    P = r * [0,3/2,0,-3/2,-3/2,0,3/2;0,sqrt(3)/2,sqrt(3),sqrt(3)/2,-sqrt(3)/2,-sqrt(3),-sqrt(3)/2].';
    P_diff = P - repmat(p',B,1);
    phi = atan2(P_diff(:,2),P_diff(:,1));
    Phi = [cos(phi).';sin(phi).'];
    Phi_tilde = Phi(:,1:M);
    Phi_bar = Phi(:,M+1:B);
    for scenario = 1  %scenario_range
        n_scenario = n_scenario + 1;
        gamma_gen = a_range(scenario) - b_range(scenario)*h_b + c_range(scenario)/h_b;
        gamma_true = ones(B,1)*gamma_gen;
        bar_gamma = gamma_true(M+1:B,1);
        for b = 1 : B
                x_tilde(b) = P(b,1) - p_true(1);
                y_tilde(b) = P(b,2) - p_true(2);
                if b <= M    
                    tau_true(b) = (1/c) * (sqrt(x_tilde(b)^2 + y_tilde(b)^2) + l_true(b));
                else
                    tau_true(b) = (1/c) * (sqrt(x_tilde(b)^2 + y_tilde(b)^2));
                end
                d_true(b) = c * tau_true(b);
                alpha_true(b) = sqrt( kappa * ( d_0/d_true(b) )^(gamma_true(b)) );
                frac(b) = 1 + (gamma_true(b)^2)/(8 * pi^2 * beta_bar^2 * tau_true(b)^2);
                sigma2_true(b) = 1 / ( 8 * pi^2 * SNR * alpha_true(b)^2 * beta_bar^2 * frac(b));
        end % b
        bar_sigma2 = sigma2_true(M+1:B)';
        for n_R = 1 : N_R
            for b = 1 : B
                u_1(b) = randn;
                hat_tau_gen(b) = tau_true(b) + sqrt(sigma2_true(b)) * u_1(b);
            end
            hat_bar_tau = hat_tau_gen(M+1:B)';
            p_in = p_true + randn(1,1);
            bar_eta_in = [p_in;gamma_true(M+1,1)] + randn(3,1);
            hat_p_LS = fminsearch('LS_quick_search',p_in,[],hat_bar_tau,P,M,B,c);
            hat_p_WLS_known_gamma = fminsearch('WLS_known_gamma_original_search',p_in,[],hat_bar_tau,bar_gamma,beta_bar,d_0,SNR,P,M,B,c,kappa);
            hat_p_ML_known_gamma  =  fminsearch('ML_known_gamma_original_search',p_in,[],hat_bar_tau,bar_gamma,beta_bar,d_0,SNR,P,M,B,c,kappa);
            SE_p_LS(n_r,n_R) = sum((hat_p_LS - p_true).^2);
            SE_p_WLS_known_gamma(n_r,n_R) = sum((hat_p_WLS_known_gamma - p_true).^2);
            SE_p_ML_known_gamma(n_r,n_R) = sum((hat_p_ML_known_gamma - p_true).^2);
            error_p_LS(:,n_R) = hat_p_LS - p_true;
            error_p_WLS_known_gamma(:,n_R) = hat_p_WLS_known_gamma - p_true;
            error_p_ML_known_gamma(:,n_R) = hat_p_ML_known_gamma - p_true;
        end
        RMSE_p_LS(n_r) = sqrt(mean(SE_p_LS(n_r,:)))
        RMSE_p_WLS_known_gamma(n_r) = sqrt(mean(SE_p_WLS_known_gamma(n_r,:)))
        B_LS_theory = c^2 * inv(Phi_bar * Phi_bar') * Phi_bar * diag( sigma2_true(M+1:B) ) * Phi_bar' * inv(Phi_bar * Phi_bar');
        RMSE_p_LS_theory(n_r) = sqrt( trace( B_LS_theory ) );
        RMSE_p_ML_known_gamma(n_r) = sqrt(mean(SE_p_ML_known_gamma(n_r,:)))
        B_pp_given_gamma =  c^2 * (1 / ( 8 * pi^2 * beta_bar^2 * SNR)) *  inv(Phi_bar* diag(alpha_true(M+1:B))^2 * (eye(B-M) + ...
                            (1/(16 * pi^2 * beta_bar^2)) * diag(gamma_true(M+1:B))^2 * inv( diag(tau_true(M+1:B))^2 ) ) * Phi_bar');
        bias_p_LS(n_r) = mean(sqrt( error_p_LS(1,:).^2 + error_p_LS(2,:).^2 ));
        bias_p_WLS_known_gamma(n_r) =  mean(sqrt(error_p_WLS_known_gamma(1,:).^2 + error_p_WLS_known_gamma(2,:).^2 ));
        bias_p_ML_known_gamma(n_r) = mean(sqrt( error_p_ML_known_gamma(1,:).^2 + error_p_ML_known_gamma(2,:).^2 ));
        CRB_p_given_gamma(n_r) = sqrt(trace(B_pp_given_gamma)); 
    end
end

 figure
 hold on
 %subplot(2,1,1);
 grid on
 plot(r_range,RMSE_p_LS,'r*','LineWidth',.5,'MarkerEdgeColor','r','MarkerSize',5)
 plot(r_range,RMSE_p_LS_theory,':r','LineWidth',.5,'MarkerEdgeColor','r','MarkerSize',5)
 plot(r_range,RMSE_p_WLS_known_gamma,'mo','LineWidth',.5,'MarkerEdgeColor','m','MarkerSize',5)
 plot(r_range,RMSE_p_ML_known_gamma,'bs','LineWidth',.5,'MarkerEdgeColor','b','MarkerSize',5)
 plot(r_range,CRB_p_given_gamma,'-k','LineWidth',.5,'MarkerEdgeColor','k','MarkerSize',5)
 legend('LS: simulation','LS: analysis','WLS: simulation','ML: simulation','CRB')
 h = findobj(gcf,'type','axes','tag','legend');
 Pos = get(h,'position');
 Pos(3) = 1.9 * Pos(3); % Double the length
 Pos(4) = 3 * Pos(4); % Double the length
 set(h,'position',Pos) % Implement it
 title('RMSE as a function of cell radius')
 ylabel('Root Mean Square Error (m)')%,'FontSize',10,'FontName','Times New Roman')
 xlabel('Cell Radius (m)')%,'FontSize',10,'FontName','Times New Roman')
 %axis([min(xi_range) max(xi_range) min(varepsilon_CRB(4,:)) max(varepsilon_CRB(3,:))])
 hold off
 
 figure
 hold on
 %subplot(2,1,2);
 grid on
 plot(r_range,bias_p_LS,'r*','LineWidth',.5,'MarkerEdgeColor','r','MarkerSize',5)
 plot(r_range,bias_p_WLS_known_gamma,'mo','LineWidth',.5,'MarkerEdgeColor','m','MarkerSize',5)
 plot(r_range,bias_p_ML_known_gamma,'bs','LineWidth',.5,'MarkerEdgeColor','b','MarkerSize',5)
 legend('LS: simulation','WLS: simulation','ML: simulation','CRB')
 h = findobj(gcf,'type','axes','tag','legend');
 Pos = get(h,'position');
 Pos(3) = 1.9 * Pos(3); % Double the length
 Pos(4) = 3 * Pos(4); % Double the length
 set(h,'position',Pos) % Implement it
 title('Bias as a function of cell radius')
 ylabel('Bias (m)')%,'FontSize',10,'FontName','Times New Roman')
 xlabel('Cell Radius (m)')%,'FontSize',10,'FontName','Times New Roman')
 %axis([min(xi_range) max(xi_range) min(varepsilon_CRB(4,:)) max(varepsilon_CRB(3,:))])
 hold off
 
 set(0,'defaulttextinterpreter','none')%laprint