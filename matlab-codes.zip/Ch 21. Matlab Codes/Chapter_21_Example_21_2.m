% MatLab code for the generating Sigma Points Table 21.1
%
% INPUT: 
% x     - mean of the Gaussian distribution
% P     - covariance matrix of the Gaussian distribution
% kappa - parameter kappa
%
%OUTPUT:
% W     - weights of Sigma Points
% X     - Sigma Points X(:,1) is the first Sigma Points
%         and X(:,end) is the last Sigma Points

function [W,X] = generateSP(x,P,kappa)

x = x(:);
n = length(x); 
X = x*ones(1,2*n+1);
X = X+sqrt(n+kappa)*[zeros(n,1), sqrtm(P), -sqrtm(P)];
W = [kappa/(n+kappa), ones(1,2*n)/(2*(n+kappa))];
