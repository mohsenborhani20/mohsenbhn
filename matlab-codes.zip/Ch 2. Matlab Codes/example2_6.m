% TOA Based Positioning
% main function for showing MSE performance versus L

%There are two for loops. The first loop is to vary the receiver number 
%from L=3 to L=8 while the second loop is to produce 1000 independent position
%estimates. Prior to performing the first loop, we construct a matrix R which 
%contains all receiver coordinates

close all
clear all
clc
x1 = [0,0];
x2 = [10,0];
x3 = [10,10];
x4 = [0,10];
x5 = [0 5];
x6 = [5 0];
x7 = [10 5];
x8 = [5 10];
R = [x1;x2;x3;x4;x5;x6;x7;x8]'; % matrix of receivers
x = [2,3]'; % source position to be determined (inside)
% x = [2,-3]'; % source position to be determined (outside)
not = 1e3; % number of trials

dB = 30; % SNR (in dB) which is defined as the mean of squared distance over noise variance
range_L = 3:8; % range of number of receivers
m = 0;
for L = range_L
    X = R(:,1:L); % matrix for receiver positions
    d = (sqrt(sum((x*ones(1,L)-X).^2,1)))'; %noise-free ranges 
    sigma2 = d.^2/10^(dB/10); % sigma2--square of sigma, here we use: SNR_dB = 10log(d^2/sigma^2)
    for run = 1:not
        r = d + randn(L,1).*sqrt(sigma2);
        
        % Nonlinear Approaches
        iter = 20;
        % == Newton-Raphson algorithm == %
        x_nr_nls(run,:) = nr_nls(X,r,iter);
        x_nr_ml(run,:) = nr_ml(X,r,iter,sigma2);
        % == Gauss-Netwon algorithm == %
        %x_gn_nls(run,:) = gn_nls(X,r,iter);
        %x_gn_ml(run,:) = gn_ml(X,r,iter,sigma2);
        % == Steepest descent algorithm == %
        %mu_nls = 0.1;
        %x_sd_nls(run,:) = sd_nls(X,r,iter,mu_nls);
        %mu_ml = 0.001;
        %x_sd_ml(run,:) = sd_ml(X,r,iter,mu_ml,sigma2);
        
        % Linear Approaches
        x_lls(run,:) = lls(X,r); 
        x_wls(run,:) = wlls(X,r,sigma2);
        x_wls2(run,:) = wls2(X,r,sigma2);
        x_sub(run,:) = sub(X,r);
        
    end;
    m = m + 1
    mse_nr_nls(m) = mean(sum((x_nr_nls - ones(not, 1)*x').^2, 2));
    mse_nr_ml(m) = mean(sum((x_nr_ml - ones(not, 1)*x').^2, 2));
    
    %mse_gn_nls(m) = mean(sum((x_gn_nls - ones(not, 1)*x').^2, 2));
    %mse_gn_ml(m) = mean(sum((x_gn_ml - ones(not, 1)*x').^2, 2));
    
    %mse_sd_nls(m) = mean(sum((x_sd_nls - ones(not, 1)*x').^2, 2));
    %mse_sd_ml(m) = mean(sum((x_sd_ml - ones(not, 1)*x').^2, 2));
    
    mse_lls(m) = mean(sum((x_lls - ones(not, 1)*x').^2, 2));
    mse_wls(m) = mean(sum((x_wls - ones(not, 1)*x').^2, 2));
    mse_wls2(m) = mean(sum((x_wls2 - ones(not, 1)*x').^2, 2));
    mse_sub(m) = mean(sum((x_sub - ones(not, 1)*x').^2, 2));

    crb(m) = crlb([x X]', sigma2);
end

% figure
% plot(Receivers(1,:), Receivers(2,:), 'bs'), hold on
% plot(x(1),x(2), 'ro'), hold on
% legend('receiver', 'source')
% xlabel('x-coordinate')
% ylabel('y-coordinate')

figure;
plot(range_L, 10*log10(mse_nr_nls), 'ko', range_L,10*log10(mse_nr_ml), 'k+',range_L, 10*log10(crb), 'k-');
legend('NLS','ML','CRLB');
ylabel('mean square position error (dB)')
xlabel('number of receivers')

figure
plot(range_L, 10*log10(mse_lls), 'k.', range_L,10*log10(mse_wls), 'ko',...
    range_L,10*log10(mse_wls2), 'k+',range_L, 10*log10(mse_sub), 'k^',...
    range_L, 10*log10(crb), 'k-');
legend('LLS','WLLS','two-step WLS','subspace','CRLB');
ylabel('mean square position error (dB)')
xlabel('number of receivers')

%figure;
%plot(range_L, 10*log10(mse_gn_nls), 'bo', range_L,10*log10(mse_gn_ml), 'r*',range_L, 10*log10(crb), 'k-');
%legend('GN-NLS','GN-ML','CRLB');
%ylabel('mean square position error (dB)')
%xlabel('number of receivers')
%figure;
%plot(range_L, 10*log10(mse_sd_nls), 'bo', range_L,10*log10(mse_sd_ml), 'r*',range_L, 10*log10(crb), 'k-');
%legend('SD-NLS','SD-ML','CRLB');
%ylabel('mean square position error (dB)')
%xlabel('number of receivers')