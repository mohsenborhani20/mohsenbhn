function C = CRB(G, phi)

  [F, Nr] = size(G);
  for n=1:Nr 
     Gt(:,n) = gradient(G(:,n), phi);
  end
  FA = 0;  FB = 0;
  for i = 1 : Nr
    FA = FA + ( Gt(:,i) ).^2;
    FB = FB + ( Gt(:,i) );
  end
  C = Nr./((Nr * FA)  - (FB.^2)); 