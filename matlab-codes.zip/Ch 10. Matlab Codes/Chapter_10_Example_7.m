function PS_LSE = DOA_LSE_1D(Gain, RSSI)
 
 %  DOA estimates using the Mininum Error algorithm. 
 %  size(Gain) = #phi x Nr;  
 %  RSSI(X) = Nr x #Repetition; 
 
 [P, N] = size(Gain);
 PS = zeros(P,1);
   for h = 1 : P 
       PS_LSE(h) =  norm((mean(RSSI)' - squeeze(Gain(h,:))));
   end 