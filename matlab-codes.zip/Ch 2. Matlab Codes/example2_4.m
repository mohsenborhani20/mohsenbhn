% TOA Based Positioning
% main function for showing MSE performance of different approaches
% versus SNR

%There are two for loops, namely, for dB = range_dB and
%for run = 1:not, to produce 1000 independent position estimates for
%the investigated methods at each SNR point. The functions
%lls, wlls, wls2 and sub correspond to (2.88), (2.122), (2.133), and
%(2.153), respectively.
%Their MSPEs at different SNR points are stored in 
%mse_lls, mse_wls, mse_wls2 and mse_sub, while crb is a vector
%which contains the corresponding CRLB values. Finally, we plot the
%MSPE in dB scale with the use of the command 10*log10.

close all
clear all
clc
x1 = [0,0];
x2 = [0,10];
x3 = [10,0];
x4 = [10,10];
X = [x1;x2;x3;x4]'; % matrix for receiver positions
L = size(X,2); % number of receivers
x = [2,3]'; % source position to be determined (inside)
% x = [2,-3]'; % source position to be determined (outside)
d = (sqrt(sum((x*ones(1,L)-X).^2,1))).'; %noise-free ranges 
not = 1e3; % number of trials
range_dB =-10:5:60; % range of SNR (in dB) which is defined as the mean of squared distance over noise variance
m = 0;
for dB = range_dB
    sigma2 = d.^2/10^(dB/10); % sigma2--square of sigma, here we use: SNR_dB = 10log(d^2/sigma^2)
    for run = 1:not
        r = d + randn(L,1).*sqrt(sigma2);
        
        x_lls(run,:) = lls(X,r); 
        x_wls(run,:) = wlls(X,r,sigma2);
        x_wls2(run,:) = wls2(X,r,sigma2);
        x_sub(run,:) = sub(X,r);
        
    end;
    m = m + 1
    
    mse_lls(m) = mean(sum((x_lls - ones(not, 1)*x').^2, 2));
    mse_wls(m) = mean(sum((x_wls - ones(not, 1)*x').^2, 2));
    mse_wls2(m) = mean(sum((x_wls2 - ones(not, 1)*x').^2, 2));
    mse_sub(m) = mean(sum((x_sub - ones(not, 1)*x').^2, 2));

    %crb(m) = crlb([x X]', sigma2);
end

plot(range_dB, 10*log10(mse_lls), 'k.', range_dB,10*log10(mse_wls), 'ko',...
    range_dB,10*log10(mse_wls2), 'k+',range_dB, 10*log10(mse_sub), 'k^');
legend('LLS','WLLS','two-step WLS','subspace');
ylabel('mean square position error (dB)')
xlabel('SNR (dB)')
% axis([-10 60 -45 45])

% figure;
% plot(range_dB, 10*log10(mse_gn_nls), 'bo', range_dB,10*log10(mse_gn_ml), 'r*',range_dB, 10*log10(crb), 'k-');
% legend('GN-NLS','GN-ML','CRLB');
% 
% figure;
% plot(range_dB, 10*log10(mse_sd_nls), 'bo', range_dB,10*log10(mse_sd_ml), 'r*',range_dB, 10*log10(crb), 'k-');
% legend('SD-NLS','SD-ML','CRLB');

