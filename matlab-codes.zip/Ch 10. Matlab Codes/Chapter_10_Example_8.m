function P_MUSIC = DOA_music_1D(Gain, RSSI)

%  the repetition of RSSI measurement made through the Antennas.
%  size(Gain) = #theta xx Nr  if Gain is a pattern                                    
%  size(Sample) = K x Nr; 

[T,  N] = size(Gain); % Gain dimension
[K, n] = size(RSSI);  % RSSI Vectors dimension 
X = 10.^(RSSI/10);    % convert signal from dB scale into linear
G = 10.^(Gain/10);      % same with antenna gains

% Compute an estimate of the Spatial Covariance Matrix
R_SS = zeros(N);
for k = 1 : K
    R_SS  = R_SS  +  (X(k,:))'*(X(k,:));
end
R_SS = R_SS/K;

[U,D,V] = svd(R_SS);   % singular value decomposition
Un = zeros(N);  Un(:,2:N) = U(:,2:N);
H = Un*Un';            

P_MUSIC = zeros(T);
%compute the music spectrum
 for i = 1 : T
         g = squeeze(G(i,:))';
         P_MUSIC(i, j) = 1 / (g * H * g');
 end