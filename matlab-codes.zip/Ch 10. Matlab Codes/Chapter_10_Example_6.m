function PS_strongest = DOA_strongest_1D(Gain, RSSI)

  % cumulative gain
  [G_cum, G_ind] = sort(Gain, 2,'descend');

  % maximum RSSI
  [R_max, R_ind] = max(mean(RSSI))
  PS_strongest = (R_ind == G_ind(:,1));