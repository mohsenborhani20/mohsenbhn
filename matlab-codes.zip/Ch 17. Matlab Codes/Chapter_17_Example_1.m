clear; clc;

Ktheta=50; 
noise_var=1; 
epsilon=0.5; 
kappa=100;
[Rx_pos,true_toa,meas_toa]=Chapter_17_Function_1(Ktheta,noise_var,epsilon,kappa);