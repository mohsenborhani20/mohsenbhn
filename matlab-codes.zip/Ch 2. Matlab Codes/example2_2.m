% TOA Based Positioning
% main function for showing position estimates of the nonlinear ML approaches
% in a single trial

%There are three main parts in example2_2, namely,
%generating range measurements, position estimation using the ML
%estimator which is realized by the Newton-Raphson, Gauss-Newton and
%steepest descent methods, and displaying results.

close all
clear all
clc

% == generating range measurements == %
%We use x1, x2, x3 and x4 to assign the
%receiver positions and X is a 4x1 matrix to store
%their coordinates while the source position to be determined is 
%x. For 2D positioning, the dimension is L=2. The noise-free
%range vector is d and its noisy version is r. The noise
%component in r is a zero-mean white Gaussian vector with
%variances given by sigma2. Moreover, both SNR in dB and number
%of iterations in the local search schemes, denoted by dB and
%iter, respectively, are set to 30.

x1 = [0,0];
x2 = [0,10];
x3 = [10,0];
x4 = [10,10];
X = [x1;x2;x3;x4]'; % matrix for receiver positions
x = [2,3]'; % source position to be determined
L = size(X,2); % number of receivers
d = (sqrt(sum((x*ones(1,L)-X).^2,1))).'; %noise-free ranges 
dB = 30; % SNR (in dB) which is defined as the mean of squared distance over noise variance
sigma2 = d.^2/10^(dB/10); % sigma2--square of sigma, here we use: SNR_dB = 10log(d^2/sigma^2)    
r = d + randn(L,1).*sqrt(sigma2);
iter = 30;

% == position estimation == %
% == ML Newton-Raphson algorithm == %
%The initial position estimate is (3,2). The Hessian
%matrix and gradient vector, denoted by H and g, are
%computed according to (2.61) and (2.65), respectively,
%while the position estimate is updated using (2.60). The
%trajectory of the position estimates versus the iteration number is
%stored in x_nr.

x=[3,2]'; %initial guess value
for i=1:iter
    H=hessian_ml(X,x,r,sigma2);
    g=grad_ml(X,x,r,sigma2);
    x=x-inv(H)*g;
    x_nr(i,:)=x;
end

% == ML Gauss-Newton algorithm == %
%Similarly, the updating equation of (2.66) is employed. Note that G is 
%the Jacobian matrix computed from (2.48)

x=[3,2]';
for i = 1:iter
    G = jacob(X, x);
    f_TOA = sqrt(sum((ones(L,1)*x'-X').^2,2));
    C_inv = diag(1./sigma2);
    x = x+inv(G'*C_inv*G)*G'*C_inv*(r-f_TOA);
    x_gn(i,:)=x;
end

% == ML steepest descent algorithm == %
%Similarly, the updating equation of (2.67) is employed. Note that the step 
%size parameter mu is now chosen as mu = 0.005 to ensure stability.

x=[3,2]';
mu= 0.005;
for i=1:iter
    g=grad_ml(X,x,r,sigma2);
    x=x-mu*g;
    x_sd(i,:)=x;
end

% == displaying results == %
iter_no = 1:iter;
figure
plot(iter_no, x_nr(:,1), 'k.', iter_no, x_gn(:,1), 'ko', iter_no, x_sd(:,1), 'k+');
legend('Newton-Raphson','Gauss-Netwon','steepest descent');
ylabel('estimate of x')
xlabel('number of iterations')
%axis([1 30 1.9 2.7])

figure
plot(iter_no, x_nr(:,2), 'k.', iter_no, x_gn(:,2), 'ko', iter_no, x_sd(:,2), 'k+');
legend('Newton-Raphson','Gauss-Netwon','steepest descent');
ylabel('estimate of y')
xlabel('number of iterations')
% axis([1 30 2.1 2.8])




