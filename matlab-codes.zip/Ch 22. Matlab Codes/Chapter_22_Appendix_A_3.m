function [DCM,r,p,y] = imu_align...
      (data1,t_coarse, Ts,[other inputs for further operations])

g = 1; % IMU's normalized gravity

% Coarse alignment
% Block Nr.1
coarseSamples = ceil(t_coarse/Ts);
axMean = mean(data1(1:coarseSamples,4));
ayMean = mean(data1(1:coarseSamples,5));
azMean = mean(data1(1:coarseSamples,6));
gtot = sqrt(axMean^2 + ayMean^2 + azMean^2);

% Block Nr.2
gnorm = sqrt(gtot^2 - axMean^2);
r = -asin(sign(ayMean/gnorm)*...
            min(gtot,abs(ayMean/gnorm)));

% Block Nr.3
gnorm = gtot^2;
p = asin(sign(axMean/gnorm)*...
             min(gtot,abs(axMean/gnorm)));

% heading/yaw y is computed exploiting the magnetometers
% or the rotational rate of the earth
