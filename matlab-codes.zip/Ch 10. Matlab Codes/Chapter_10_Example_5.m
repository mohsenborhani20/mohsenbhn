Target = [4, 5];                          %Target Position
DOA = atan2(Target(2), Target(1));     %DOA respect (0,0)
Distance = norm(Target,2);             %BS-Target Distance
lambda_0 = .2998/2.45;                 %lambda at 2.45 GHz 
Prx = -10*np*log10(4*pi*Distance/lambda_0);
idx = min(find( abs(DOA  - phi) < pi/360)); 

for n = 1:Nr
RSSI(:,n) = floor((repmat(Prx + G_AN(idx, n),[repetition, 1]) +...
   (10^(-.1*SNR))*randn(repetition, 1)));
end 