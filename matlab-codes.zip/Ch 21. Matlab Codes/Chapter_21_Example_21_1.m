% MatLab code for the Update step 3. 
% of Algorithm 21.1 Gaussian Mixture Filter
%
% INPUT: 
% prior - Assume that prior distribution after step 2. is
%         prior = 1xn struct array with fields: alpha,xhat,Phat
%         Here n is the number of components, 
%         alphas are the weights of the components,
%         xhats are the means of the components and
%         Phats are the covariance matrixes of the components.
% y     - Measurement:
%         y_i = norm(x-xbs_i)+v_i,
%         where measurement noise v_i is zero mean idependet 
%         Gaussian with variance meas_sigma^2. 
%         We assume that we have M measurement (M = length(y)).
% XBS   - position vectors of base stations XBS(:,i) = xbs_i
% R     - meas_sigma^2*eye(length(y))
%
%OUTPUT Eq. (21.20):
% posterior = 1xn struct array with fields: alpha, xhat, Phat

function posterior = updateGMF(prior,y,XBS,R)

posterior = prior;

for i=1:length(prior)
    % Compute derivative of measurement function Eq. (21.21c)
    % length of position vector (usually 2 or 3)
    dim = size(XBS,1);
    xmu = prior(i).xhat(1:dim);
    for j = 1:length(y)
        % if h(x)=norm(s-x) then h'(x)=-(s-x)'/norm(s-x)
        H(j,:) = [-(XBS(:,j)-xmu)'/norm(XBS(:,j)-xmu),zeros(1,dim)];
        % innovation (last part of Eq. (21.21d))
        inno(j,1) = y(j)-norm(XBS(:,j)-xmu);
    end
    P = prior(i).Phat;
    % Compute Kalman gain Eq. (21.21f)
    P_inno = H*P*H'+R;
    K = P*H'/P_inno;
    % Eq. (21.21d)
    posterior(i).xhat = prior(i).xhat+K*inno;
    % Eq. (21.21e)
    posterior(i).Phat = (eye(2*dim)-K*H)*P;
    % Eq. (21.21b) without normalization
    posterior(i).alpha = prior(i).alpha/sqrt(det(2*pi*P_inno))*...
                         exp(-1/2*inno'*(P_inno\inno));
    
end

% Normalization
alpha_sum = sum([posterior(:).alpha]);
for i=1:length(posterior)
    posterior(i).alpha = posterior(i).alpha/alpha_sum;
end
