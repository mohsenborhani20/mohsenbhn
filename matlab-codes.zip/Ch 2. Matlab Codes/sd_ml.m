function x = sd_ml(X,r,iter,mu,sigma2)
% Maximum Likelihood
% Local search scheme: Steepest descent algorithm
% --------------------------------
% x = sd_ml(X,r,iter,mu,sigma2)
% x = 2D position estimate
% X = matrix for receiver positions
% r = TOA measurement vector
% iter = number of iterations
% mu = step size
% sigma2 = noise variance vector
%

x=wlls(X,r,sigma2);
for i=1:iter
    g=grad_ml(X,x,r,sigma2);
    x=x-mu*g;
end
