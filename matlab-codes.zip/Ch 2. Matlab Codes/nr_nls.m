function x = nr_nls(X,r,iter)
% Nonlinear Least Squares
% Local search scheme: Newton-Raphson algorithm
% --------------------------------
% x = nr_nls(X,r,iter)
% x = 2D position estimate
% X = matrix for receiver positions
% r = TOA measurement vector
% iter = number of iterations
%

x=lls(X,r);
for i=1:iter
    H=hessian_nls(X,x,r);
    g=grad_nls(X,x,r);
    x=x-inv(H)*g;
end



