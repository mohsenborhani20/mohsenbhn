function x = wls2(X,r,sigma2)
% two-step WLS algorithm
% --------------------------------
% x = wls2(X,r,sigma2)
% x = 2D position estimate
% X = matrix for receiver positions
% r = TOA measurement vector
% sigma2 = noise variance vector
% 
L = size(X,2); % number of receivers

% first step
A = [-2*X' ones(L,1)];
b = r.^2-sum(X'.^2,2);
W = (1/4)*diag(1./(sigma2.*r.^2));
C = pinv(A'*W*A);
z = C*A'*W*b;

% second step
s = sign(z(1:2));
G = [1 0;0 1;1 1];
h = [z(1)^2;z(2)^2;z(3)];
Phi = pinv(diag([2*z(1:2);1])*C*diag([2*z(1:2);1]));
z = pinv(G'*Phi*G)*G'*Phi*h;
x = real(sign(s).*sqrt(z));

